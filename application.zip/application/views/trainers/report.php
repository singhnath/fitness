
<div class="site-content">
<div class="content-area py-1">

<div class="container-fluid">

 <div id="content">

  <div id="content-header"  class="page-title">

    <h2>Report </h2>

   <!--  <div class="span6">

      <button class="btn btn-success" name="new_vendor">Add New</button>

    </div> -->

  </div>

  <div class="container-fluid">
   <div class="row-fluid">
      <div class="span12">
        <div class="box">
            <div class="box-body">
            <div class="chart tab-pane active" id="revenue-chart"
                       style="position: relative;     text-align: center; padding:20px">
                      <!-- <canvas id="revenue-chart-canvas" height="300" style="height: 300px;"></canvas> -->
                      <!-- <img src="<?php echo base_url(); ?>img/home-chart.png"/> -->
                      <div class="box box-info">
                            <div class="box-header with-border">
                                <h3 class="box-title">Report Monthly Chart</h3>
                                <!-- <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse">
                                        <i class="fa fa-minus"></i>
                                    </button>
                                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                                </div> -->
                            </div>
                            <div class="box-body">
                                <div class="chart">
                                    <canvas id="oltmsVoltageChart" style="height:250px"></canvas>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>

                   </div>
            </div>
        </div>

      </div>

    </div>

  </div>

</div>

</div>

</div>

</div>