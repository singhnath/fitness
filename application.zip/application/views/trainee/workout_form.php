

<div class="site-content">

<div class="content-area py-1">

<div class="container-fluid">

	<div class="container-fluid">

    <div class="row-fluid">

      <div class="span12">

        <div class="widget-box">

                    <div class="page-title" > 

                      <h2>Create Workout Plan</h2>

                    </div>

                    <?php
                       
                    ?>

               <div class="widget-content nopadding">
          <div class="col-xl-12 col-lg-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title">Create Workout </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php //echo validation_errors(); ?>
            <form role="form" method="post" name="form">
                <div class="box-body">
                    <div class="row">
                        <!-- <div class="col-xs-5">
                             <div class="form-group">
                                <label>Trainee</label>
                                <select class="form-control">
                                    <option>select Trainee</option>
                                    <option>select Trainee 2</option>
                                    <option>select Trainee 3</option>
                                    <option>select Trainee 4</option>
                                    <option>select Trainee 5</option>
                                </select>
                            </div>
                        </div> -->
                        <div class="col-xs-5">
                             <div class="form-group">
                                <label>Day</label>
                                <select class="form-control">
                                    <option>select Day</option>
                                    <option>Day 2</option>
                                    <option>Day 3</option>
                                    <option>Day 4</option>
                                    <option>Day 5</option>
                                </select>
                            </div>
                        </div>
                    </div>   
                    <div class="row">
                        <div class="col-xs-5">
                             <div class="form-group">
                                <label>Workout</label>
                                <select class="form-control">
                                    <option>select Workout</option>
                                    <option>Leg</option>
                                    <option>Leg 1</option>
                                    <option>Leg 2</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-5">
                            <div class="form-group">
                            <label for="exampleInputEmail1">How many <small>(repetition did you do ?)</small></label>
                            <input type="text" class="form-control" placeholder="20">
                            </div>
                        </div>
                    </div>   
                    <div class="row">
                        <div class="col-xs-5">
                             <div class="form-group">
                                <label>Workout</label>
                                <select class="form-control">
                                    <option>select Workout</option>
                                    <option>Back</option>
                                    <option>Back 1</option>
                                    <option>Back 2</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-xs-5">
                            <div class="form-group">
                            <label for="exampleInputEmail1">How many <small>(repetition did you do ?)</small></label>
                            <input type="text" class="form-control" placeholder="20">
                            </div>
                        </div>
                        <div class="col-xs-2">
                            <ul class="add-list">
                                <li><a href="#" title="add"><i class="fa fa-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#" title="delete"><i class="fa fa-trash" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>              
                    <div class="box-footer" style="margin-top:20px">
                    <button type="submit" class="btn ">Save</button>
                    </div>
                </div>
              <!-- /.box-body -->

              
            </form>
          </div>
          <!-- /.box -->
        </div>

        </div>

        </div>

      </div>

    </div>

  </div>

	

</div>

</div>

</div>